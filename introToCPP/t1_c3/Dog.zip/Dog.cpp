/**
    VFS Intro to C++
    Purpose: Pointer exercises using a class

    @class Intro to Programming in C++
    @version 1.1
*/

#include <iostream>

class Dog
{
public:

	Dog()
	{
		mNoises = 0;
	}
	
	void Woof()
	{
		std::cout << "WOOF!" << std::endl;
		++mNoises;
	}

private:

	int mNoises;

};

//
// EXECISE ONE
//

//
// create a function called "CreateDog" that returns an instance of "Dog" using dynamically allocated memory
//


// >>> SOLVE HERE <<<


//
// EXECISE TWO
//

//
// create a function called "BarkThreeTimes" that uses an instance returned from "CreateDog" and then makes the dog bark three times
//


// >>> SOLVE HERE <<<


//
// EXECISE THREE
//

//
// 1. create a function called "ThreeDogsBark2" that takes three "Dog" pointers as parameters and then makes each dog bark once
// 2. create a function called "ThreeDogsBark1" that creates three dogs using "CreateDog" and then passes them to "ThreeDogsBark2"



// >>> SOLVE HERE <<<


//
// EXECISE FOUR
//

// create a function called "ThreeDogsBarkStack" that creates three "Dog" instances on the stack and then passes them to "ThreeDogsBark2"
//


// >>> SOLVE HERE <<<



int main()
{
	//
	// add test code here
	//
	
	return 0;
}